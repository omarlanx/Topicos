package interfaz;

import javax.swing.*;
import java.awt.BorderLayout;

public class UnoV2 extends JFrame {

	public UnoV2() {
		super("*ITC*");
		setVisible(true);
		setSize(350,150);
		setLocation(400,200);
		JLabel Etiqueta1 = new JLabel("HOLA MUNDO",SwingConstants.CENTER);
		add(Etiqueta1);
		JLabel Etiqueta2 = new JLabel("HOLA MUNDO",SwingConstants.CENTER);
		add(Etiqueta2,BorderLayout.NORTH);		
	}

	public static void main(String[] args) {
		UnoV2 Obj = new UnoV2();
		Obj.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

}
