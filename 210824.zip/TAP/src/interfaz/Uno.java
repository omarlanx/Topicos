package interfaz;
import javax.swing.*;

public class Uno {

	public static void main(String[] args) {
		JFrame Marco = new JFrame("ITC");
		JLabel Etiqueta = new JLabel("Hola mundo, hecho con swing",SwingConstants.CENTER);
		JLabel Etiqueta2 = new JLabel("Topicos Avanzados de Programación",SwingConstants.CENTER);
		Marco.add(Etiqueta);
		Marco.add(Etiqueta2);
		Marco.setVisible(true);
		Marco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		

	}

}
